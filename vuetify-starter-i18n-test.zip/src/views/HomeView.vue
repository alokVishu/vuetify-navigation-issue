<script setup lang="ts">
</script>

<template>
  <main>
    <p>Aadmin</p>
  </main>
</template>
