import { createI18n } from 'vue-i18n'

// const messages = Object.fromEntries(
//   Object.entries(
//     // eslint-disable-next-line @typescript-eslint/no-explicit-any
//     import.meta.glob<{ default: any }>('./locales/*.json', { eager: true }))
//     .map(([key, value]) => [key.slice(10, -5), value.default]),
// )

const messages = {
  en: {
    message: {
      the_world: 'the world',
      dio: 'DIO:',
      linked: '@:message.dio @:message.the_world !!!!',
      msg:'If you are using the vue-i18n library, you can very easily integrate it with Vuetify.'
    }
  },
  ar: {
    message: {
      the_world: 'العالم',
      dio: 'ديور:',
      linked: 'العالم',
      msg:'إذا كنت تستخدم مكتبة vue-i18n ، فيمكنك دمجها بسهولة مع Vuetify.'
    }
  }
}

export default createI18n({
  legacy: false,
  locale: 'en',
  fallbackLocale: 'en',
  messages,
})
