<script setup lang="ts">
import { useI18n } from 'vue-i18n';
import { RouterLink, RouterView } from 'vue-router';

const { locale } = useI18n({ useScope: 'global' })
</script>

<template>
  <VApp>

    <VMain class="wrapper">
      <v-row>
        <v-col cols="4" class="border-e">
          <nav>
          <v-list>
            <v-list-item>
              <RouterLink to="/" class="me-3">{{ $t('message.the_world') }}</RouterLink>
            </v-list-item>
            <v-list-item>
              <RouterLink to="/about">{{ $t('message.dio') }}</RouterLink>
            </v-list-item>
            <v-list-item>
              <RouterLink to="/about">{{ $t('message.linked') }}</RouterLink>
            </v-list-item>

            <v-list-item>
              <v-menu>
                <template v-slot:activator="{ props }">
                  <v-btn
                    color="primary"
                    v-bind="props"
                  >
                    Translate
                  </v-btn>
                </template>

                <v-list>
                  <v-list-item @click="locale = 'en'">EN</v-list-item>
                  <v-list-item @click="locale = 'ar'">AR</v-list-item>
                </v-list>
              </v-menu>
            </v-list-item>
          </v-list>
        </nav>
        </v-col>

        <v-col cols="8">
          {{$t('message.msg')}}
        </v-col>
      </v-row>

    </VMain>
  </VApp>

  <RouterView />
</template>
